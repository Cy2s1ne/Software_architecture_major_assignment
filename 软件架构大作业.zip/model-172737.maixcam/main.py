from maix import camera, display, image, nn, app
from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import base64
import io
import numpy as np
from PIL import Image
import paho.mqtt.client as mqtt
import threading
import time

# MQTT配置
MQTT_BROKER = "111.231.145.234"  # MQTT服务器地址
MQTT_PORT = 1883                  # MQTT端口
MQTT_TOPIC = "image/detection"    # MQTT主题
MQTT_CLIENT_ID = "maixpy_detector"  # MQTT客户端ID

# 初始化YOLO模型
detector = nn.YOLOv5(model="/root/models/model_172903.mud", dual_buff=True)

# MQTT客户端设置
mqtt_client = mqtt.Client(MQTT_CLIENT_ID)

def on_connect(client, userdata, flags, rc):
    """MQTT连接回调"""
    print(f"Connected to MQTT Broker with result code: {rc}")

def on_publish(client, userdata, mid):
    """MQTT发布消息回调"""
    print(f"Message {mid} published")

def setup_mqtt():
    """设置并启动MQTT客户端"""
    mqtt_client.on_connect = on_connect
    mqtt_client.on_publish = on_publish
    
    try:
        mqtt_client.connect(MQTT_BROKER, MQTT_PORT, 60)
        # 在后台线程运行MQTT客户端
        mqtt_client.loop_start()
        print("MQTT client started")
    except Exception as e:
        print(f"MQTT connection failed: {e}")

class ImageHandler(BaseHTTPRequestHandler):
    def do_OPTIONS(self):
        # 处理CORS预检请求
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')  # 允许所有域名访问
        self.send_header('Access-Control-Allow-Methods', 'POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def do_POST(self):
        if self.path == '/image':
            # 获取POST请求的数据长度
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            
            try:
                # 解析JSON数据
                json_data = json.loads(post_data.decode('utf-8'))
                image_b64 = json_data.get('image', '')
                
                # 处理base64数据
                if ',' in image_b64:
                    # 移除base64数据的头部信息
                    image_b64 = image_b64.split(',')[1]
                # 修复base64填充
                padding = 4 - (len(image_b64) % 4)
                if padding != 4:
                    image_b64 += '=' * padding
                
                # 将base64转换为二进制数据
                image_data = base64.b64decode(image_b64)
                
                # 转换为PIL图像对象
                img_pil = Image.open(io.BytesIO(image_data))
                if img_pil.mode != 'RGB':
                    img_pil = img_pil.convert('RGB')
                
                # 转换为numpy数组
                img_np = np.array(img_pil)
                
                # 创建Maix图像对象
                width, height = img_pil.size
                img = image.Image(width, height, image.Format.FMT_RGB888)
                # 将numpy数组转换为Maix图像
                img = image.cv2image(img_np, bgr=False, copy=True)
                
                # 使用YOLO模型进行目标检测
                objs = detector.detect(img, conf_th=0.5, iou_th=0.45)

                # 定义所有可能的类型
                ALL_TYPES = [
                    'crazing',
                    'patches',
                    'inclusion',
                    'pitted_surface',
                    'rolled_in_scale',
                    'scratches'
                ]

                # 初始化所有类型的计数为0
                obj_counts = {label: 0 for label in ALL_TYPES}

                # 更新检测到的目标数量
                for obj in objs:
                    label = detector.labels[obj.class_id].strip()
                    if label in obj_counts:  # 只统计预定义的类型
                        obj_counts[label] += 1
                
                # 将统计结果转换为列表格式（用于HTTP响应）
                obj_list = [{"type": label, "count": count} for label, count in obj_counts.items()]
                
                # 在图像上绘制检测结果
                for obj in objs:
                    img.draw_rect(obj.x, obj.y, obj.w, obj.h, color=image.COLOR_RED)
                    msg = f'{detector.labels[obj.class_id]}: {obj.score:.2f}'
                    img.draw_string(obj.x, obj.y, msg, color=image.COLOR_RED)
                
                # 将处理后的Maix图像转换回numpy数组
                img_np = image.image2cv(img, ensure_bgr=False, copy=True)
                
                # 转换为PIL图像
                img_pil = Image.fromarray(img_np)
                
                # 将处理后的图像转换为base64格式
                processed_img_buffer = io.BytesIO()
                img_pil.save(processed_img_buffer, format='JPEG')
                processed_img_buffer.seek(0)
                processed_img_b64 = base64.b64encode(processed_img_buffer.getvalue()).decode('utf-8')
                
                # 发布MQTT消息
                try:
                    mqtt_client.publish(
                        MQTT_TOPIC,
                        json.dumps(obj_counts, separators=(',', ':')),  # 使用 separators 参数移除空格
                        qos=1
                    )
                except Exception as e:
                    print(f"MQTT发布失败: {e}")

                # 设置HTTP响应
                self.send_response(200)
                self.send_header('Access-Control-Allow-Origin', '*')
                self.send_header('Access-Control-Allow-Methods', 'POST, OPTIONS')
                self.send_header('Access-Control-Allow-Headers', 'Content-Type')
                self.send_header('Content-type', 'application/json')
                self.end_headers()

                # 发送HTTP响应
                response = {
                    'processed_image': processed_img_b64,
                    'obj': obj_list
                }
                self.wfile.write(json.dumps(response).encode())
                
            except Exception as e:
                # 错误处理
                print(f"错误: {str(e)}")
                self.send_response(400)
                self.send_header('Access-Control-Allow-Origin', '*')
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({'error': str(e)}).encode())
        else:
            # 处理未知的路径请求
            self.send_response(404)
            self.end_headers()

def run_server():
    # 启动MQTT客户端
    setup_mqtt()
    
    # 启动HTTP服务器
    server_address = ('192.168.31.90', 8075)
    httpd = HTTPServer(server_address, ImageHandler)
    print('HTTP服务器启动在端口 8075...')
    httpd.serve_forever()

if __name__ == '__main__':
    run_server()
